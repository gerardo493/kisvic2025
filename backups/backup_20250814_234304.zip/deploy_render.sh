#!/bin/bash
echo "🚀 Desplegando a Render..."
python3 deploy_render.py
